 <div class="top-bar">
        <div class="container d-flex justify-content-between align-items-center">
            <div id="date-time">
                <i class="far fa-clock me-2 text-warning"></i> 
                <span id="bengali-date">লোড হচ্ছে...</span>
            </div>
            <div class="d-none d-md-block">
                <span class="opacity-75">নির্ভুল তথ্য, নিরাপদ সমাজ</span>
            </div>
        </div>
    </div>