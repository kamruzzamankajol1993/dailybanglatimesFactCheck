<nav class="navbar navbar-expand-lg main-navbar d-none d-lg-block sticky-top">
    <div class="container justify-content-center">
        <ul class="navbar-nav">
            
            <li class="nav-item"><a class="nav-link" href="<?php echo e(url('/')); ?>">হোম</a></li>
            
            
            <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="<?php echo e(route('front.latest.news')); ?>" role="button" data-bs-toggle="dropdown" aria-expanded="false">ক্যাটাগরি</a>
                <ul class="dropdown-menu">
                    <?php if(isset($header_categories)): ?>
                        <?php $__currentLoopData = $header_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li>
                                <a class="dropdown-item" href="<?php echo e(route('front.category.news', $category->slug)); ?>">
                                    <?php echo e($category->name); ?>

                                </a>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </ul>
            </li>

            
            <li class="nav-item"><a class="nav-link" href="<?php echo e(route('front.factFile')); ?>">ফ্যাক্ট ফাইল</a></li>
            <li class="nav-item"><a class="nav-link" href="<?php echo e(route('front.mediaLiteracy')); ?>">মিডিয়া লিটারেসি</a></li>

            
            <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">আমাদের সম্পর্কে</a>
                <ul class="dropdown-menu">
                    <li><a class="dropdown-item" href="<?php echo e(route('front.aboutUs')); ?>">আমাদের মিশন</a></li>
                    <li><a class="dropdown-item" href="<?php echo e(route('front.team')); ?>">টিম মেম্বার</a></li>
                    <li><a class="dropdown-item" href="<?php echo e(route('front.methodology')); ?>">কাজের পদ্ধতি</a></li>
                </ul>
            </li>

            
            <li class="nav-item"><a class="nav-link" href="<?php echo e(route('front.contactUs')); ?>">যোগাযোগ</a></li>
        </ul>
    </div>
</nav><?php /**PATH F:\project2025\htdocs\2026\dailybdfactcheck\resources\views/front/include/lastHeader.blade.php ENDPATH**/ ?>