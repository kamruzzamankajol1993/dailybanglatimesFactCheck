

<?php
    // --- ১. ডাটা প্রসেসিং ও নর্মালাইজেশন ---
    
    // টাইটেল
    $title = $post->title ?? ($post->link ?? 'News Details');
    
    // কন্টেন্ট (Post হলে content, Request হলে description)
    $content = $isUserRequest ? ($post->description ?? '') : ($post->content ?? '');
    
    // ইমেজ পাথ (Post হলে front_admin_url, Request হলে storage asset)
    $imageUrl = 'https://placehold.co/800x500/eee/333?text=No+Image';
    if ($post->image) {
        $imageUrl = $isUserRequest ? $front_admin_url.$post->image : $front_admin_url.$post->image;
    }

    // ক্যাটাগরি এবং স্লাগ
    $categoryName = 'News';
    $categoryLink = '#';
    if ($isUserRequest && $post->category) {
        $categoryName = $post->category->name;
        // রিকোয়েস্টের ক্যাটাগরি পেজ লিংক (যদি থাকে)
        $categoryLink = route('front.category.news', $post->category->slug ?? '#');
    } elseif (!$isUserRequest && $post->categories->count() > 0) {
        $categoryName = $post->categories->first()->name;
        $categoryLink = route('front.category.news', $post->categories->first()->slug);
    }

    // অথর
    $authorName = $isUserRequest ? 'User Submitted' : ($post->author->name ?? $front_ins_name);
    
    // তারিখ (Bangla Converter পরে অ্যাপ্লাই হবে)
    $date = $post->created_at->format('d F, Y'); 
    
    // ভিউ কাউন্ট (User Request এর কলাম না থাকলে ডিফল্ট ০)
    $viewCount = $post->view_count ?? 0;

    // --- ২. ভার্ডিক্ট লজিক ---
    $verdict = $factCheckResult->verdict ?? 'Unverified';
    
    // API রেসপন্স থেকে কমেন্ট বের করা
    $rawApi = json_decode($factCheckResult->api_response_raw ?? '{}', true);
    // যদি API কমেন্ট না থাকে, তবে অ্যাডমিন কমেন্ট, তাও না থাকলে ডিফল্ট মেসেজ
    $comment = $rawApi['comment'] ?? ($post->admin_comment ?? 'বিস্তারিত বিশ্লেষণ শীঘ্রই আসছে...');

    // ডিফল্ট স্টাইল (Unverified)
    $verdictColor = '#6c757d'; // grey
    $verdictIcon = 'fa-question-circle';
    $verdictText = $verdict;

    // ভার্ডিক্ট কালার লজিক
    if (stripos($verdict, 'True') !== false || stripos($verdict, 'Likely True') !== false) {
        $verdictColor = '#198754'; // success green
        $verdictIcon = 'fa-check-circle';
        $verdictText = 'সত্য (True)';
    } elseif (stripos($verdict, 'False') !== false || stripos($verdict, 'Fake') !== false) {
        $verdictColor = '#dc3545'; // danger red
        $verdictIcon = 'fa-times-circle';
        $verdictText = 'মিথ্যা (False)';
    } elseif (stripos($verdict, 'Misleading') !== false) {
        $verdictColor = '#ffc107'; // warning yellow
        $verdictIcon = 'fa-exclamation-triangle';
        $verdictText = 'বিভ্রান্তিকর (Misleading)';
    } elseif (stripos($verdict, 'Altered') !== false) {
        $verdictColor = '#fd7e14'; // orange
        $verdictIcon = 'fa-edit';
        $verdictText = 'বিকৃত (Altered)';
    }
?>

<?php $__env->startSection('title'); ?>
<?php echo e($title); ?> | <?php echo e($front_ins_name); ?> 
<?php $__env->stopSection(); ?>

<?php $__env->startSection('meta'); ?>
    <meta name="description" content="<?php echo e(Str::limit(strip_tags($content), 150)); ?>">
    <meta name="keywords" content="<?php echo e($categoryName); ?>">
    <meta name="author" content="<?php echo e($authorName); ?>">
    <meta property="og:title" content="<?php echo e($title); ?>">
    <meta property="og:description" content="<?php echo e(Str::limit(strip_tags($content), 150)); ?>">
    <meta property="og:image" content="<?php echo e($imageUrl); ?>">
    <meta property="og:url" content="<?php echo e(url()->current()); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<style>
    /* --- DETAIL PAGE SPECIFIC CSS --- */
    .article-header { padding: 40px 0 20px; }
    .article-title { font-size: 2.5rem; font-weight: 700; color: var(--primary); line-height: 1.3; }
    .article-meta { font-size: 0.9rem; color: #666; margin-top: 15px; border-bottom: 1px solid #eee; padding-bottom: 20px; }
    .article-meta span { margin-right: 15px; }
    
    .article-featured-img { width: 100%; height: auto; border-radius: 8px; margin-bottom: 30px; box-shadow: 0 5px 15px rgba(0,0,0,0.05); }
    
    /* Verdict Box (Dynamic Color) */
    .verdict-box { background: #fff; border-left: 5px solid <?php echo e($verdictColor); ?>; padding: 25px; margin-bottom: 30px; box-shadow: 0 4px 15px rgba(0,0,0,0.05); border-radius: 5px; }
    .verdict-label { font-size: 0.8rem; text-transform: uppercase; letter-spacing: 1px; color: #888; font-weight: 700; }
    .verdict-result { font-size: 1.5rem; font-weight: 700; color: <?php echo e($verdictColor); ?>; margin-bottom: 15px; }
    
    .claim-grid { display: grid; grid-template-columns: 100px 1fr; gap: 15px; margin-bottom: 10px; }
    .claim-grid strong { color: var(--primary); }
    
    /* Article Content */
    .article-content { font-size: 1.1rem; line-height: 1.8; color: #333; }
    .article-content h3 { font-weight: 700; margin-top: 30px; margin-bottom: 15px; color: var(--primary); }
    .article-content img { max-width: 100%; height: auto; }
    .article-content a { color: var(--accent); text-decoration: none; }
    
    /* Sidebar Mini Cards */
    .sidebar-widget { background: #fff; padding: 20px; margin-bottom: 30px; border: 1px solid #eee; }
    .mini-card { display: flex; gap: 10px; margin-bottom: 15px; padding-bottom: 15px; border-bottom: 1px solid #f9f9f9; }
    .mini-card img { width: 80px; height: 60px; object-fit: cover; border-radius: 4px; }
    .mini-card h6 { font-size: 0.95rem; line-height: 1.4; margin: 0; }
    .mini-card a { color: #333; text-decoration: none; }
    .mini-card a:hover { color: var(--accent); }


    /* Share Buttons */
    .share-section { margin-top: 40px; padding-top: 20px; border-top: 1px solid #eee; }
    
    .btn-social { 
        width: 40px; height: 40px; 
        display: inline-flex; align-items: center; justify-content: center; 
        border-radius: 50%; color: white; margin-right: 10px; 
        transition: 0.3s; text-decoration: none; 
    }
    
    .btn-fb { background: #3b5998; }       /* Facebook */
    .btn-x { background: #000000; }        /* X (Twitter) */
    .btn-in { background: #0077b5; }       /* LinkedIn */
    .btn-wa { background: #25d366; }       /* WhatsApp */
    .btn-yt { background: #ff0000; }       /* YouTube */
    .btn-print { background: #6c757d; cursor: pointer; }    /* Print */
    
    .btn-social:hover { opacity: 0.8; color: white; transform: translateY(-3px); }
    
    /* প্রিন্ট করার সময় বাটনগুলো লুকানো থাকবে */
    @media print {
        .share-section, .no-print { display: none !important; }
    }
    
   



</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
    
    <?php
        function convertToBangla($str) {
            $en_num = ['0','1','2','3','4','5','6','7','8','9'];
            $bn_num = ['০','১','২','৩','৪','৫','৬','৭','৮','৯'];
            $en_months = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
            $bn_months = ['জানুয়ারি', 'ফেব্রুয়ারি', 'মার্চ', 'এপ্রিল', 'মে', 'জুন', 'জুলাই', 'আগস্ট', 'সেপ্টেম্বর', 'অক্টোবর', 'নভেম্বর', 'ডিসেম্বর'];
            
            $str = str_replace($en_months, $bn_months, $str);
            return str_replace($en_num, $bn_num, $str);
        }
    ?>

     <section class="bg-white pb-5">
        <div class="container">
            <div class="row">
                
                
                <div class="col-lg-8">
                    
                    
                    <div class="article-header">
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb small text-uppercase">
                                <li class="breadcrumb-item"><a href="<?php echo e(route('front.index')); ?>" class="text-danger">হোম</a></li>
                                <li class="breadcrumb-item"><a href="<?php echo e($categoryLink); ?>" class="text-danger"><?php echo e($categoryName); ?></a></li>
                                <li class="breadcrumb-item active">ফ্যাক্ট-চেক</li>
                            </ol>
                        </nav>
                        
                        <h1 class="article-title"><?php echo e($title); ?></h1>
                        
                        <div class="article-meta">
                            <span><i class="fas fa-user-edit me-2"></i>প্রতিবেদক: <strong><?php echo e($authorName); ?></strong></span>
                            <span><i class="far fa-calendar-alt me-2"></i><?php echo e(convertToBangla($date)); ?></span>
                            <span><i class="fas fa-eye me-2"></i><?php echo e(convertToBangla($viewCount)); ?> বার পঠিত</span>
                        </div>
                    </div>

                    
                    <?php if($factCheckResult): ?>
                    <div class="verdict-box">
                        <div class="verdict-label">ফ্যাক্ট-চেক রেজাল্ট</div>
                        <div class="verdict-result">
                            <i class="fas <?php echo e($verdictIcon); ?> me-2"></i><?php echo e($verdictText); ?>

                        </div>
                        
                        <div class="claim-grid">
                            <strong>বিশ্লেষণ:</strong>
                            <div style="text-align: justify;">
                                <?php echo $comment; ?>

                            </div>
                        </div>
                        
                        
                        <?php if($factCheckResult->confidence_score): ?>
                        <div class="mt-2 text-end">
                             <span class="badge bg-light text-secondary border">AI কনফিডেন্স: <?php echo e($factCheckResult->confidence_score * 100); ?>%</span>
                        </div>
                        <?php endif; ?>
                    </div>
                    <?php endif; ?>

                    
                    <img src="<?php echo e($imageUrl); ?>" alt="<?php echo e($title); ?>" class="article-featured-img">

                    
                    <div class="article-content text-justify">
                        
                        <?php if(!$isUserRequest && $post->subtitle): ?>
                             <h4 class="mb-3 text-secondary"><?php echo e($post->subtitle); ?></h4>
                        <?php endif; ?>
                        
                        
                        <?php echo $content; ?>


                        
                        <?php if($factCheckResult): ?>
                        <div class="alert mt-5 py-3" style="background-color: <?php echo e($verdictColor); ?>15; border-left: 5px solid <?php echo e($verdictColor); ?>; color: #333;">
                            <h5 class="alert-heading fw-bold"><i class="fas fa-info-circle me-2"></i>সিদ্ধান্ত</h5>
                            <p class="mb-0">
                                আমাদের যাচাই প্রক্রিয়া এবং উপলব্ধ তথ্যের ভিত্তিতে এই দাবিটি <strong><?php echo e($verdictText); ?></strong> হিসেবে প্রমাণিত হয়েছে।
                            </p>
                        </div>
                        <?php endif; ?>
                    </div>

                    
                    
                    <div class="share-section no-print">
                        <h5 class="fw-bold mb-3">শেয়ার করুন:</h5>
                        
                        
                        <a href="https://www.facebook.com/sharer/sharer.php?u=<?php echo e(url()->current()); ?>" target="_blank" class="btn-social btn-fb" title="Facebook">
                            <i class="fab fa-facebook-f"></i>
                        </a>
                        
                        
                        <a href="https://twitter.com/intent/tweet?url=<?php echo e(url()->current()); ?>&text=<?php echo e($title); ?>" target="_blank" class="btn-social btn-x" title="X (Twitter)">
                            <i class="fab fa-x-twitter"></i>
                        </a>

                        
                        <a href="https://www.linkedin.com/sharing/share-offsite/?url=<?php echo e(url()->current()); ?>" target="_blank" class="btn-social btn-in" title="LinkedIn">
                            <i class="fab fa-linkedin-in"></i>
                        </a>

                        
                        <a href="https://wa.me/?text=<?php echo e(url()->current()); ?>" target="_blank" class="btn-social btn-wa" title="WhatsApp">
                            <i class="fab fa-whatsapp"></i>
                        </a>

                        
                        
                        <?php
                            $youtubeLink = '#';
                            if(isset($social_links)) {
                                foreach($social_links as $link) {
                                    if(stripos($link->title, 'youtube') !== false) {
                                        $youtubeLink = $link->link;
                                        break;
                                    }
                                }
                            }
                        ?>
                        <a href="<?php echo e($youtubeLink); ?>" target="_blank" class="btn-social btn-yt" title="Subscribe on YouTube">
                            <i class="fab fa-youtube"></i>
                        </a>

                        
                        <button onclick="window.print()" class="btn-social btn-print border-0" title="Print this Article">
                            <i class="fas fa-print"></i>
                        </button>
                    </div>

                </div>

                
                <div class="col-lg-4 mt-5 mt-lg-0">
                    
                    
                    <div class="sidebar-widget mt-lg-5">
                        <h4 class="widget-title mb-4 pb-2 border-bottom">সাম্প্রতিক যাচাই</h4>
                        
                        <?php $__currentLoopData = $latestNews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lNews): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                // সাইডবার আইটেম প্রসেসিং
                                $sTitle = $lNews->title;
                                $sLink = route('front.news.details', $lNews->slug);
                                $sImage = $lNews->image ? $front_admin_url.$lNews->image : 'https://placehold.co/100';
                                
                                // সাইডবার আইটেম ভার্ডিক্ট
                                $sVerdict = $lNews->factCheck->verdict ?? 'Unverified';
                                $sClass = 'text-secondary';
                                if (stripos($sVerdict, 'True') !== false) $sClass = 'text-success';
                                elseif (stripos($sVerdict, 'False') !== false) $sClass = 'text-danger';
                                elseif (stripos($sVerdict, 'Misleading') !== false) $sClass = 'text-warning';
                            ?>

                            <div class="mini-card">
                                <img src="<?php echo e($sImage); ?>" alt="<?php echo e($sTitle); ?>">
                                <div>
                                    <h6><a href="<?php echo e($sLink); ?>"><?php echo e(Str::limit($sTitle, 40)); ?></a></h6>
                                    <small class="<?php echo e($sClass); ?> fw-bold"><?php echo e($sVerdict); ?></small>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        <a href="<?php echo e(route('front.latest.news')); ?>" class="btn btn-sm btn-outline-dark w-100 mt-2">আরও দেখুন</a>
                    </div>

                    
                    <div class="sidebar-widget">
                        <h4 class="widget-title mb-3">ক্যাটাগরি</h4>
                        <div class="d-flex flex-wrap gap-2">
                            <?php $__empty_1 = true; $__currentLoopData = $sidebarCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <a href="<?php echo e(route('front.category.news', $cat->slug)); ?>" class="badge bg-light text-dark border p-2 text-decoration-none">
                                    <?php echo e($cat->name); ?>

                                </a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <span class="text-muted small">কোনো ক্যাটাগরি পাওয়া যায়নি।</span>
                            <?php endif; ?>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.master.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH F:\project2025\htdocs\2026\dailybdfactcheck\resources\views/front/news/details.blade.php ENDPATH**/ ?>