<div class="offcanvas offcanvas-start" tabindex="-1" id="mobileMenu">
    <div class="offcanvas-header border-bottom">
        <a href="<?php echo e(url('/')); ?>">
             
            <img src="<?php echo e($front_admin_url); ?><?php echo e($front_mobile_version_logo); ?>" alt="Logo" style="max-height: 50px; width: auto;">
        </a>
        <button type="button" class="btn-close" data-bs-dismiss="offcanvas"></button>
    </div>
    <div class="offcanvas-body d-flex flex-column">
        <ul class="navbar-nav mb-5">
            
            <li class="nav-item">
                <a class="nav-link text-dark border-bottom py-2 fw-bold" href="<?php echo e(url('/')); ?>">হোম</a>
            </li>

            
            <?php if(isset($header_categories)): ?>
                <?php $__currentLoopData = $header_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($category->children->count() > 0): ?>
                        
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle text-dark border-bottom py-2 fw-bold" href="#" data-bs-toggle="dropdown">
                                <?php echo e($category->name); ?>

                            </a>
                            <ul class="dropdown-menu border-0 bg-light">
                                
                                <li>
                                    <a class="dropdown-item ps-4 fw-bold" href="<?php echo e(route('front.category.news', $category->slug)); ?>">
                                        সব দেখুন
                                    </a>
                                </li>
                                
                                <?php $__currentLoopData = $category->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li>
                                        <a class="dropdown-item ps-4" href="<?php echo e(route('front.category.news', $child->slug)); ?>">
                                            <?php echo e($child->name); ?>

                                        </a>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </li>
                    <?php else: ?>
                        
                        <li class="nav-item">
                            <a class="nav-link text-dark border-bottom py-2 fw-bold" href="<?php echo e(route('front.category.news', $category->slug)); ?>">
                                <?php echo e($category->name); ?>

                            </a>
                        </li>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>

            
            <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle text-dark border-bottom py-2 fw-bold" href="#" data-bs-toggle="dropdown">আমাদের সম্পর্কে</a>
                <ul class="dropdown-menu border-0 bg-light">
                    <li><a class="dropdown-item ps-4" href="<?php echo e(route('front.aboutUs')); ?>">মিশন ও ভিশন</a></li>
                    <li><a class="dropdown-item ps-4" href="<?php echo e(route('front.team')); ?>">টিম মেম্বার</a></li>
                     <li><a class="dropdown-item ps-4" href="<?php echo e(route('front.methodology')); ?>">কাজের পদ্ধতি</a></li>
                </ul>
            </li>
             <li class="nav-item"><a class="nav-link text-dark border-bottom py-2 fw-bold" href="<?php echo e(route('front.factFile')); ?>">ফ্যাক্ট ফাইল</a></li>
            <li class="nav-item"><a class="nav-link text-dark border-bottom py-2 fw-bold" href="<?php echo e(route('front.mediaLiteracy')); ?>">মিডিয়া লিটারেসি</a></li>
            <li class="nav-item">
                <a class="nav-link text-dark border-bottom py-2 fw-bold" href="<?php echo e(route('front.contactUs')); ?>">যোগাযোগ</a>
            </li>
        </ul>

        
        <div class="mt-auto text-center">
            <p class="small text-muted fw-bold mb-3">ফলো করুন</p>
            <div class="d-flex justify-content-center gap-2 mb-4">
                <?php $__currentLoopData = $social_links; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $title = strtolower($link->title);
                        $iconClass = 'fas fa-link';
                        $brandClass = '';

                        if(str_contains($title, 'facebook')) {
                            $iconClass = 'fab fa-facebook-f';
                            $brandClass = 'sb-fb';
                        } elseif(str_contains($title, 'twitter') || $title == 'x') {
                            $iconClass = 'fa-brands fa-x-twitter';
                            $brandClass = 'sb-x';
                        } elseif(str_contains($title, 'instagram')) {
                            $iconClass = 'fab fa-instagram';
                            $brandClass = 'sb-in';
                        } elseif(str_contains($title, 'youtube')) {
                            $iconClass = 'fab fa-youtube';
                            $brandClass = 'sb-yt';
                        } elseif(str_contains($title, 'linkedin')) {
                            $iconClass = 'fab fa-linkedin-in';
                            $brandClass = 'sb-li';
                        }
                    ?>
                    
                    <a href="<?php echo e($link->link); ?>" target="_blank" class="social-btn <?php echo e($brandClass); ?>" title="<?php echo e($link->title); ?>">
                        <i class="<?php echo e($iconClass); ?>"></i>
                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</div><?php /**PATH F:\project2025\htdocs\2026\dailybdfactcheck\resources\views/front/include/offcanvas.blade.php ENDPATH**/ ?>