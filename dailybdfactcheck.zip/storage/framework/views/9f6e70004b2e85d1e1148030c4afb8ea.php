<footer>
    <div class="container">
        <div class="row">
            
            <div class="col-lg-4 mb-5">
                <a href="<?php echo e(url('/')); ?>" class="d-block mb-4 text-decoration-none">
                    <?php if(!empty($front_mobile_version_logo)): ?>
                        <img src="<?php echo e($front_admin_url); ?><?php echo e($front_mobile_version_logo); ?>" alt="<?php echo e($front_ins_name); ?>" style="max-height: 70px; width: auto;">
                    <?php else: ?>
                        <h4 class="text-white en-font"><?php echo e($front_ins_name); ?></h4>
                    <?php endif; ?>
                </a>
                <p class="small text-secondary pe-lg-4">
                    <?php echo e(Str::limit($front_ins_d, 350)); ?>

                </p>
            </div>

            
            <div class="col-lg-2 col-6 mb-4">
                <h5 class="text-white mb-3">কুইক লিংকস</h5>
                <ul class="list-unstyled small text-secondary">
                    <li><a href="<?php echo e(url('/')); ?>" class="text-decoration-none text-secondary d-block py-1 hover-white">হোম</a></li>
                    <li><a href="<?php echo e(route('front.aboutUs')); ?>" class="text-decoration-none text-secondary d-block py-1 hover-white">আমাদের সম্পর্কে</a></li>
                    <li><a href="<?php echo e(route('front.privacyPolicy')); ?>" class="text-decoration-none text-secondary d-block py-1 hover-white">গোপনীয়তা নীতি</a></li>
                    <li><a href="<?php echo e(route('front.termsCondition')); ?>" class="text-decoration-none text-secondary d-block py-1 hover-white">শর্তাবলী</a></li>
                </ul>
            </div>

            
            <div class="col-lg-2 col-6 mb-4">
                <h5 class="text-white mb-3">ক্যাটাগরি</h5>
                <ul class="list-unstyled small text-secondary">
                    <?php if(isset($header_categories)): ?>
                        <?php $__currentLoopData = $header_categories->take(5); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li>
                            <a href="<?php echo e(route('front.category.news', $category->slug)); ?>" class="text-decoration-none text-secondary d-block py-1 hover-white">
                                <?php echo e($category->name); ?>

                            </a>
                        </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </ul>
            </div>

            
            <div class="col-lg-4 mb-4">
                <h5 class="text-white mb-3">যোগাযোগ</h5>
                <ul class="list-unstyled small text-secondary">
                    
                    
                    <?php if(!empty($front_ins_add)): ?>
                    <li class="mb-3">
                        <div class="d-flex">
                            <i class="fas fa-map-marker-alt mt-1 me-2 text-danger"></i> 
                            <div>
                                <strong class="d-block text-white">বাংলাদেশ অফিস:</strong>
                                <?php echo e($front_ins_add); ?>

                            </div>
                        </div>
                    </li>
                    <?php endif; ?>

                    
                    <?php if(!empty($front_us_office_address)): ?>
                    <li class="mb-3">
                        <div class="d-flex">
                            <i class="fas fa-globe-americas mt-1 me-2 text-danger"></i> 
                            <div>
                                <strong class="d-block text-white">ইউএস অফিস:</strong>
                                <?php echo e($front_us_office_address); ?>

                            </div>
                        </div>
                    </li>
                    <?php endif; ?>

                    
                    <?php if(!empty($front_ins_email)): ?>
                    <li class="mb-2">
                        <i class="fas fa-envelope me-2 text-danger"></i> 
                        <?php echo e($front_ins_email); ?>

                    </li>
                    <?php endif; ?>

                    
                    <?php if(!empty($front_ins_phone)): ?>
                    <li class="mb-2">
                        <i class="fas fa-phone me-2 text-danger"></i> 
                        <?php echo e($front_ins_phone); ?>

                    </li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </div>
    
    <div class="footer-bottom border-top border-secondary py-3 mt-4" style="border-color: #222 !important;">
        <div class="container text-center">
            <small class="text-secondary">
                &copy; <?php echo e(date('Y')); ?> <?php echo e($front_ins_name ?? 'FactCheckBD'); ?>। সর্বস্বত্ব সংরক্ষিত।
            </small>
        </div>
    </div>
</footer><?php /**PATH F:\project2025\htdocs\2026\dailybdfactcheck\resources\views/front/include/footer.blade.php ENDPATH**/ ?>