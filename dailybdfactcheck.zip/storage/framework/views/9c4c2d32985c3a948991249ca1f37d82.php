

<?php $__env->startSection('title'); ?>
পুরানো সংবাদ আর্কাইভ
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
 <style>
        .archive-control-box {
            background-color: #006a4e; /* Brand Green */
            padding: 20px;
            border-radius: 4px;
            color: white;
        }
        .archive-card-img {
            height: 160px;
            object-fit: cover;
            transition: transform 0.3s;
            width: 100%;
        }
        .card:hover .archive-card-img {
            transform: scale(1.05);
        }
        .calendar-widget {
            background: white;
            border: 1px solid #ddd;
        }
        .calendar-header {
            background: #dc3545;
            color: white;
            padding: 10px;
            text-align: center;
            font-weight: bold;
            font-size: 18px;
        }
        /* Calendar Link Styles */
        .calendar-date-link {
            display: block;
            width: 30px;
            height: 30px;
            line-height: 30px;
            text-align: center;
            text-decoration: none;
            color: #333;
            border-radius: 50%;
            margin: 0 auto;
            transition: 0.2s;
        }
        .calendar-date-link:hover {
            background-color: #eee;
            color: #dc3545;
        }
        .calendar-date-link.active-date {
            background-color: #006a4e;
            color: white;
            font-weight: bold;
        }
        .calendar-date-link.is-friday {
            color: #dc3545;
            font-weight: bold;
        }
    </style>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('body'); ?>
 <section class="py-4">
        <div class="container">

            <div class="row g-4">
                
                
                <div class="col-lg-9">
                    
                    
                    <div class="archive-control-box shadow-sm mb-4">
                        <form action="<?php echo e(route('front.archive')); ?>" method="GET">
                            <div class="row g-3 align-items-end">
                                <div class="col-12"><h4 class="mb-0 border-bottom pb-2 border-white"><i class="fas fa-calendar-alt me-2"></i>পুরানো সংবাদ খুঁজুন</h4></div>
                                
                                <div class="col-md-5">
                                    <label class="small fw-bold mb-1 text-light">তারিখ নির্বাচন করুন</label>
                                    <input type="date" name="date" value="<?php echo e($searchDate); ?>" class="form-control rounded-0 border-0">
                                </div>
                                
                                <div class="col-md-5">
                                    <label class="small fw-bold mb-1 text-light">বিভাগ (অপশনাল)</label>
                                    <select name="category" class="form-select rounded-0 border-0">
                                        <option value="all">সকল বিভাগ</option>
                                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($cat->id); ?>" <?php echo e($searchCategory == $cat->id ? 'selected' : ''); ?>>
                                                <?php echo e($cat->name); ?>

                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>

                                <div class="col-md-2">
                                    <button type="submit" class="btn btn-danger w-100 rounded-0 fw-bold">খুঁজুন</button>
                                </div>
                            </div>
                        </form>
                    </div>

                    
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <h5 class="fw-bold m-0 text-dark">
                            <?php if($searchDate): ?>
                                <span class="text-danger"><?php echo e(\Carbon\Carbon::parse($searchDate)->locale('bn')->isoFormat('LL')); ?></span> - এর সংবাদ
                            <?php else: ?>
                                <span class="text-danger">সর্বশেষ সংবাদ</span>
                            <?php endif; ?>
                        </h5>
                        <span class="badge bg-secondary">মোট <?php echo e($posts->total()); ?> টি সংবাদ</span>
                    </div>

                    
                    <div class="row g-3">
                        <?php if($posts->count() > 0): ?>
                            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-md-4 col-sm-6">
                                    <div class="card h-100 border-0 shadow-sm overflow-hidden">
                                        <div class="overflow-hidden">
                                            <img src="<?php echo e($post->image ? $front_admin_url.$post->image : 'https://placehold.co/300x200/222/fff?text=No+Image'); ?>" 
                                                 class="card-img-top archive-card-img rounded-0"
                                                 loading="lazy">
                                        </div>
                                        <div class="card-body p-3">
                                            <?php if($post->categories->isNotEmpty()): ?>
                                                <small class="text-danger fw-bold d-block mb-1">
                                                    <?php echo e($post->categories->first()->name); ?>

                                                </small>
                                            <?php endif; ?>
                                            <a href="<?php echo e(route('front.news.details', $post->slug)); ?>" class="text-decoration-none text-dark">
                                                <h6 class="fw-bold hover-red lh-base m-0"><?php echo e(Str::limit($post->title, 60)); ?></h6>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <div class="col-12 text-center py-5">
                                <h4 class="text-muted">দুঃখিত! এই তারিখে কোনো সংবাদ পাওয়া যায়নি।</h4>
                            </div>
                        <?php endif; ?>
                    </div>

                    
                    <div class="mt-5 d-flex justify-content-center">
                        <?php echo e($posts->links('pagination::bootstrap-5')); ?>

                    </div>

                </div>

                
                <div class="col-lg-3">
                    <div class="sticky-top" style="top: 100px;">
                        
                        
                        <div class="bg-white border rounded shadow-sm mb-4">
                            <div class="p-3 border-bottom bg-light">
                                <h6 class="fw-bold m-0 text-danger">মাসের আর্কাইভ</h6>
                            </div>
                            <div class="list-group list-group-flush small">
                                <?php $__currentLoopData = $monthlyArchives; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $archive): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                        // মাসের নাম বাংলায় কনভার্ট করা
                                        $monthName = \Carbon\Carbon::createFromDate($archive->year, $archive->month, 1)->locale('bn')->isoFormat('MMMM YYYY');
                                        // ওই মাসের ১ তারিখের লিংক জেনারেট
                                        $queryDate = \Carbon\Carbon::createFromDate($archive->year, $archive->month, 1)->format('Y-m-d');
                                    ?>
                                    <a href="<?php echo e(route('front.archive', ['date' => $queryDate])); ?>" class="list-group-item list-group-item-action d-flex justify-content-between align-items-center">
                                        <?php echo e($monthName); ?> 
                                        <span class="badge bg-secondary rounded-pill"><?php echo e($archive->count); ?></span>
                                    </a>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>

                        
                        <div class="calendar-widget shadow-sm mb-4">
                            <div class="calendar-header">
                                
                                <?php echo e($calendarData['banglaMonth']); ?>

                            </div>
                            <div class="p-3 text-center">
                                <table class="table table-sm table-borderless m-0 small">
                                    <thead>
                                        <tr class="text-secondary border-bottom">
                                            <th class="text-danger">রবি</th><th>সোম</th><th>মঙ্গল</th><th>বুধ</th><th>বৃহঃ</th><th class="text-danger">শুক্র</th><th>শনি</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                            $dayCount = 1;
                                            $totalDays = $calendarData['daysInMonth'];
                                            $startDay = $calendarData['startDayOfWeek']; // 0 = Sunday
                                            $rows = ceil(($startDay + $totalDays) / 7);
                                        ?>

                                        <?php for($i = 0; $i < $rows; $i++): ?>
                                            <tr>
                                                <?php for($j = 0; $j < 7; $j++): ?>
                                                    <?php if($i == 0 && $j < $startDay): ?>
                                                        
                                                        <td></td>
                                                    <?php elseif($dayCount > $totalDays): ?>
                                                        
                                                        <td></td>
                                                    <?php else: ?>
                                                        <?php
                                                            // বর্তমান লুপের তারিখ তৈরি করা
                                                            $thisDate = \Carbon\Carbon::createFromDate($calendarData['year'], $calendarData['month'], $dayCount)->format('Y-m-d');
                                                            $isActive = ($searchDate == $thisDate);
                                                            $isFriday = ($j == 5); // শুক্রবার চেক
                                                        ?>
                                                        <td>
                                                            <a href="<?php echo e(route('front.archive', ['date' => $thisDate])); ?>" 
                                                               class="calendar-date-link <?php echo e($isActive ? 'active-date' : ''); ?> <?php echo e($isFriday ? 'is-friday' : ''); ?>">
                                                                <?php echo e(str_replace(range(0,9), ['০','১','২','৩','৪','৫','৬','৭','৮','৯'], $dayCount)); ?>

                                                            </a>
                                                        </td>
                                                        <?php $dayCount++; ?>
                                                    <?php endif; ?>
                                                <?php endfor; ?>
                                            </tr>
                                        <?php endfor; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        
                        <div class="text-center">
                            
                            <?php if(isset($archive_sidebar_ad)): ?>
                                
                                <?php if($archive_sidebar_ad->type == 1 && !empty($archive_sidebar_ad->image)): ?>
                                    <a href="<?php echo e($archive_sidebar_ad->link ?? 'javascript:void(0)'); ?>" <?php echo e(!empty($archive_sidebar_ad->link) ? 'target="_blank"' : ''); ?>>
                                        <img src="<?php echo e($front_admin_url); ?>public/<?php echo e($archive_sidebar_ad->image); ?>" 
                                             class="img-fluid border" 
                                             alt="Archive Advertisement"
                                             style="width: 100%; height: auto;">
                                    </a>
                                
                                
                                <?php elseif($archive_sidebar_ad->type == 2 && !empty($archive_sidebar_ad->script)): ?>
                                    <?php echo $archive_sidebar_ad->script; ?>

                                <?php endif; ?>
                            <?php else: ?>
                                
                                <div style="background: #eee; height: 250px; display: flex; align-items: center; justify-content: center; color: #999;">
                                    বিজ্ঞাপন
                                </div>
                            <?php endif; ?>
                        </div>

                    </div>
                </div>

            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.master.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH F:\project2025\htdocs\2026\dailybdfactcheck\resources\views/front/archive.blade.php ENDPATH**/ ?>