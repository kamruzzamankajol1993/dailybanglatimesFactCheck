<!DOCTYPE html>
<html lang="bn">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <meta name="robots" content="index, follow">

    
    <?php if (! empty(trim($__env->yieldContent('meta')))): ?>
        <?php echo $__env->yieldContent('meta'); ?>
    <?php else: ?>
        
        <meta name="description" content="<?php echo e($front_ins_d); ?>">
        <meta name="keywords" content="<?php echo e($front_ins_k); ?>">
        <meta name="author" content="<?php echo e($front_ins_name); ?> Team">

        <meta property="og:type" content="website">
        <meta property="og:url" content="<?php echo e(url()->current()); ?>">
        <meta property="og:title" content="<?php echo e($front_ins_name); ?>">
        <meta property="og:description" content="<?php echo e($front_ins_d); ?>">
        <meta property="og:image" content="<?php echo e($front_admin_url); ?><?php echo e($front_mobile_version_logo); ?>">

        <meta name="twitter:card" content="summary_large_image">
        <meta name="twitter:title" content="<?php echo e($front_ins_name); ?>">
        <meta name="twitter:description" content="<?php echo e($front_ins_d); ?>">
        <meta name="twitter:image" content="<?php echo e($front_admin_url); ?><?php echo e($front_mobile_version_logo); ?>">
    <?php endif; ?>
   
    <title><?php echo $__env->yieldContent('title'); ?></title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
    
    <link href="https://fonts.googleapis.com/css2?family=Hind+Siliguri:wght@300;400;500;600;700&family=Poppins:wght@300;400;600;700&family=Playfair+Display:wght@700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('/')); ?>public/front/css/style.css">
    <link rel="shortcut icon" href="<?php echo e($front_admin_url); ?><?php echo e($front_icon_name); ?>">
      <?php echo $__env->yieldContent('css'); ?>
</head>
<body class="bg-light">


    <!-- Top Header Include -->
 <?php echo $__env->make('front.include.topHeader', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?> 
    <!-- End Top Header Include -->

     <!-- Header include -->
     <?php echo $__env->make('front.include.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <!-- End Header include -->

    <!-- Headline Include -->
    
    <!-- End Headline Include -->

    <!-- Last Header Include -->
    <?php echo $__env->make('front.include.lastHeader', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <!-- End Last Header Include -->
  <!-- Offcanvas Include -->
    <?php echo $__env->make('front.include.offcanvas', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <!-- End Offcanvas Include -->

    <!-- Main Content -->
    <?php echo $__env->yieldContent('body'); ?>
    <!-- End Main Content -->

    <!-- Footer Include -->
    <?php echo $__env->make('front.include.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <!-- End Footer Include -->

  
   
   
    
 <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"
        integrity="sha512-v2CJ7UaYy4JwqLDIrZUI/4hqeoQieOmAZNXBeQyjo21dadnwR+8ZaIJVT8EE2iyI61OV8e6M8PP2/4hpQINQ/g=="
        crossorigin="anonymous" referrerpolicy="no-referrer"></script>
   <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
     <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
  
    <script>
        function updateDateTime() {
            const now = new Date();
            const options = { 
                weekday: 'long', year: 'numeric', month: 'long', day: 'numeric',
                hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: true
            };
            const dateStr = now.toLocaleString('bn-BD', options);
            document.getElementById('bengali-date').textContent = dateStr ;
        }
        updateDateTime();
        setInterval(updateDateTime, 1000); 
    </script>
  <?php echo $__env->yieldContent('scripts'); ?>
</body>
</html><?php /**PATH F:\project2025\htdocs\2026\dailybdfactcheck\resources\views/front/master/master.blade.php ENDPATH**/ ?>