<div class="row g-4">
    <?php $__empty_1 = true; $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <?php
            // ১. ডাটা প্রসেসিং
            $title = 'No Title';
            $image = 'https://placehold.co/600x400/png?text=No+Image';
            $date = $item->created_at->format('d M, Y');
            $link = '#';
            $desc = '';

            // যদি পোস্ট থেকে আসে
            if ($item->post) {
                $title = $item->post->title;
                $image = $item->post->image ? $front_admin_url.$item->post->image : $image;
                $link = route('front.news.details', $item->post->slug);
                $desc = Str::limit(strip_tags($item->post->content), 100);
            } 
            // যদি ইউজার রিকোয়েস্ট থেকে আসে
            elseif ($item->factCheckRequest) {
                $title = $item->factCheckRequest->title ?? 'User Request';
                $image = $item->factCheckRequest->image ? $front_admin_url.$item->factCheckRequest->image : $image;
                $link = route('front.news.details', $item->factCheckRequest->id); // বা ডিটেইলস পেজ থাকলে সেটার লিংক
                $desc = Str::limit($item->factCheckRequest->description, 100);
            }

            // ২. ভার্ডিক্ট ব্যাজ কালার
            $verdict = $item->verdict;
            $badgeClass = 'bg-secondary';
            $verdictText = $verdict;

            if (stripos($verdict, 'True') !== false || stripos($verdict, 'Likely True') !== false) {
                $badgeClass = 'bg-success'; $verdictText = 'সত্য';
            } elseif (stripos($verdict, 'False') !== false || stripos($verdict, 'Fake') !== false) {
                $badgeClass = 'bg-danger'; $verdictText = 'মিথ্যা';
            } elseif (stripos($verdict, 'Misleading') !== false) {
                $badgeClass = 'bg-warning text-dark'; $verdictText = 'বিভ্রান্তিকর';
            } elseif (stripos($verdict, 'Altered') !== false) {
                $badgeClass = 'bg-info text-dark'; $verdictText = 'বিকৃত';
            }
        ?>

        <div class="col-md-6 col-lg-4">
            <div class="result-card position-relative h-100 shadow-sm border rounded overflow-hidden">
                
                <span class="badge-status <?php echo e($badgeClass); ?>" style="position: absolute; top: 10px; right: 10px; z-index: 10; padding: 5px 10px; border-radius: 4px; color: #fff; font-weight: bold; font-size: 12px;">
                    <?php echo e($verdictText); ?>

                </span>

                <div class="img-wrapper" style="height: 200px; overflow: hidden;">
                    <img src="<?php echo e($image); ?>" class="w-100 h-100 object-fit-cover transition-transform" alt="<?php echo e($title); ?>">
                </div>

                <div class="p-3">
                    <div class="meta-info mb-2 text-muted small">
                        <i class="far fa-calendar-alt me-1"></i> <?php echo e($date); ?>

                    </div>
                    <h5 class="fw-bold mb-2">
                        <a href="<?php echo e($link); ?>" class="text-dark text-decoration-none"><?php echo e(Str::limit($title, 60)); ?></a>
                    </h5>
                    <p class="small text-muted mb-3"><?php echo e($desc); ?></p>
                    <a href="<?php echo e($link); ?>" class="text-danger fw-bold small text-decoration-none">
                        আরও পড়ুন <i class="fas fa-arrow-right ms-1"></i>
                    </a>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <div class="col-12 text-center py-5">
            <div class="text-muted">
                <i class="far fa-folder-open fa-3x mb-3"></i>
                <h5>এই ক্যাটাগরিতে কোনো যাচাইকৃত খবর পাওয়া যায়নি।</h5>
            </div>
        </div>
    <?php endif; ?>
</div>


<?php if($posts->hasPages()): ?>
<div class="mt-5 d-flex justify-content-center">
    <nav aria-label="Page navigation">
        <ul class="pagination custom-pagination">
            
            <?php if($posts->onFirstPage()): ?>
                <li class="page-item disabled"><span class="page-link"><i class="fas fa-chevron-left"></i></span></li>
            <?php else: ?>
                <li class="page-item"><a class="page-link" href="<?php echo e($posts->previousPageUrl()); ?>"><i class="fas fa-chevron-left"></i></a></li>
            <?php endif; ?>

            
            <?php $__currentLoopData = $posts->links()->elements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if(is_string($element)): ?>
                    <li class="page-item disabled"><span class="page-link"><?php echo e($element); ?></span></li>
                <?php endif; ?>
                <?php if(is_array($element)): ?>
                    <?php $__currentLoopData = $element; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($page == $posts->currentPage()): ?>
                            <li class="page-item active"><span class="page-link"><?php echo e($page); ?></span></li>
                        <?php else: ?>
                            <li class="page-item"><a class="page-link" href="<?php echo e($url); ?>"><?php echo e($page); ?></a></li>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            
            <?php if($posts->hasMorePages()): ?>
                <li class="page-item"><a class="page-link" href="<?php echo e($posts->nextPageUrl()); ?>"><i class="fas fa-chevron-right"></i></a></li>
            <?php else: ?>
                <li class="page-item disabled"><span class="page-link"><i class="fas fa-chevron-right"></i></span></li>
            <?php endif; ?>
        </ul>
    </nav>
</div>
<?php endif; ?><?php /**PATH F:\project2025\htdocs\2026\dailybdfactcheck\resources\views/front/news/_category_posts_partial.blade.php ENDPATH**/ ?>