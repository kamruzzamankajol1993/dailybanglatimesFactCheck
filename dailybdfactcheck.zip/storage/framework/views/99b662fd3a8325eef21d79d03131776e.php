<section class="entertainment-section py-4 bg-light">
    <div class="container">

        <?php
            // ডিফল্ট স্লাগ (যদি ডাটা না থাকে)
            $catSlug = '#'; 
            
            // কন্ট্রোলার থেকে আসা ডাটা থেকে স্লাগ নেওয়া হচ্ছে
            if(isset($entertainmentNews) && count($entertainmentNews) > 0) {
                // প্রথম পোস্টের প্রথম ক্যাটাগরির স্লাগ নেওয়া হলো
                $catSlug = $entertainmentNews->first()->categories->first()->slug ?? '#';
            }
        ?>
        
        <div class="section-header-wrapper mb-4" style="border-bottom: 3px solid #dc3545;">
            <a href="<?php echo e($catSlug != '#' ? route('front.category.news', $catSlug) : '#'); ?>" class="text-decoration-none">
            <h5 class="bg-success text-white d-inline-block px-3 py-2 m-0 position-relative">বিনোদন</h5>
            </a>
        </div>

        <?php if(isset($entertainmentNews) && count($entertainmentNews) > 0): ?>
            <div class="row g-3">
                
                
                <div class="col-lg-5">
                    <?php $mainEnt = $entertainmentNews->first(); ?>
                    <?php if($mainEnt): ?>
                        <div class="card border-0 h-100 bg-transparent">
                            <div class="position-relative">
                                <img  onerror="this.onerror=null;this.src='<?php echo e($front_admin_url); ?><?php echo e($front_logo_name); ?>';" src="<?php echo e($mainEnt->image ? $front_admin_url.$mainEnt->image : 'https://placehold.co/600x380/333/fff?text=Entertainment'); ?>" 
                                     class="card-img-top rounded-0" 
                                     alt="<?php echo e($mainEnt->title); ?>">
                                <span class="position-absolute bottom-0 start-0 bg-dark text-white px-2 py-1 m-2 rounded"><i class="fas fa-camera"></i></span>
                            </div>
                            <div class="card-body px-0 pt-3">
                                <h4 class="card-title fw-bold hover-red">
                                    <a href="<?php echo e(route('front.news.details', $mainEnt->slug)); ?>" class="text-dark text-decoration-none hover-red">
                                        <?php echo e($mainEnt->title); ?>

                                    </a>
                                    <small class="bangla-date"><i class="far fa-clock me-1"></i><?php echo e(bangla_date($mainEnt->created_at)); ?></small>
                                </h4>
                                <p class="card-text text-secondary mt-2">
                                    <?php echo e(Str::limit(strip_tags($mainEnt->content), 150)); ?>

                                </p>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>

                
                <div class="col-lg-7">
                    <div class="row g-3">
                        <?php $__currentLoopData = $entertainmentNews->slice(1, 4); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $news): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-md-6">
                                <div class="card border-0 text-white overlay-card">
                                    <div class="position-relative">
                                        <img  onerror="this.onerror=null;this.src='<?php echo e($front_admin_url); ?><?php echo e($front_logo_name); ?>';" src="<?php echo e($news->image ? $front_admin_url.$news->image : 'https://placehold.co/300x180/444/fff?text=Ent'); ?>" 
                                             class="card-img rounded-0" 
                                             alt="<?php echo e($news->title); ?>"
                                             style="height: 180px; object-fit: cover; width: 100%;">
                                        
                                        <div class="card-img-overlay d-flex align-items-end p-0">
                                            <div class="overlay-text p-2 w-100">
                                                <h6 class="fw-bold m-0 lh-base">
                                                    <a href="<?php echo e(route('front.news.details', $news->slug)); ?>" class="text-white text-decoration-none">
                                                        <?php echo e($news->title); ?>

                                                    </a>
                                                    <small class="bangla-date"><i class="far fa-clock me-1"></i><?php echo e(bangla_date($news->created_at)); ?></small>
                                                </h6>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>

            
            <div class="row g-3 mt-1">
                <?php $__currentLoopData = $entertainmentNews->slice(5, 4); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $news): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-3 col-6">
                        <div class="card border-0 text-white overlay-card">
                            <div class="position-relative">
                                <img  onerror="this.onerror=null;this.src='<?php echo e($front_admin_url); ?><?php echo e($front_logo_name); ?>';" src="<?php echo e($news->image ? $front_admin_url.$news->image : 'https://placehold.co/300x160/222/fff?text=Ent'); ?>" 
                                     class="card-img rounded-0" 
                                     alt="<?php echo e($news->title); ?>"
                                     style="height: 160px; object-fit: cover; width: 100%;">
                                
                                <div class="card-img-overlay d-flex align-items-end p-0">
                                    <div class="overlay-text p-2 w-100">
                                        <h6 class="fw-bold m-0 small lh-base">
                                            <a href="<?php echo e(route('front.news.details', $news->slug)); ?>" class="text-white text-decoration-none">
                                                <?php echo e($news->title); ?>

                                            </a>
                                            <small class="bangla-date"><i class="far fa-clock me-1"></i><?php echo e(bangla_date($news->created_at)); ?></small>
                                        </h6>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

        <?php else: ?>
            <div class="text-center text-muted py-5">
                <p>কোনো বিনোদন সংবাদ পাওয়া যায়নি।</p>
            </div>
        <?php endif; ?>

    </div>
</section><?php /**PATH F:\project2025\htdocs\2026\dailybdfactcheck\resources\views/front/home_page/_partial/entertainment.blade.php ENDPATH**/ ?>